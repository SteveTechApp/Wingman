export type CatalogueTechnology =
  | "AV over IP"
  | "HDBaseT"
  | "Matrix Switching"
  | "Presentation / UC"
  | "USB / KVM"
  | "Cameras / Video Bars"
  | "Audio"
  | "Control"
  | "Accessories";

export type CatalogueStatus = "Current" | "New" | "Legacy" | "Coming Soon";

export type CatalogueProduct = {
  sku: string;
  name: string;
  technology: CatalogueTechnology;
  technologyTags: CatalogueTechnology[];
  category: string;
  subType: string;
  summary: string;
  status: CatalogueStatus;
  applications: string[];
  featureTags: string[];
  resolution?: string;
  distance?: string;
  transport?: string;
};

export type CatalogueFilters = {
  search: string;
  technology: CatalogueTechnology[];
  category: string[];
  subType: string[];
  featureTags: string[];
  status: CatalogueStatus[];
};

export type ProductCardView = CatalogueProduct & {
  score?: number;
};

export type CatalogueFilterGroup = {
  key: string;
  title: string;
  subtitle?: string;
  items: string[];
};

export const TECHNOLOGY_OPTIONS: CatalogueTechnology[] = [
  "AV over IP",
  "HDBaseT",
  "Matrix Switching",
  "Presentation / UC",
  "USB / KVM",
  "Cameras / Video Bars",
  "Audio",
  "Control",
  "Accessories",
];
