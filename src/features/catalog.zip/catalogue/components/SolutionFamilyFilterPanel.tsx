import React from "react";
import {
  CatalogueFilterState,
  FamilyFilterGroup,
  SOLUTION_FAMILIES,
  SolutionFamily
} from "../catalogueFilterModel";

type SolutionFamilyFilterPanelProps = {
  state: CatalogueFilterState;
  onChange: (next: CatalogueFilterState) => void;
};

const shellStyle: React.CSSProperties = {
  display: "grid",
  gap: 14
};

const sectionStyle: React.CSSProperties = {
  border: "1px solid rgba(120,160,255,0.18)",
  borderRadius: 18,
  padding: 14,
  background: "linear-gradient(180deg, rgba(7,20,45,0.95), rgba(4,13,31,0.95))",
  boxShadow: "0 12px 28px rgba(0,0,0,0.22)"
};

const titleStyle: React.CSSProperties = {
  fontSize: 13,
  letterSpacing: "0.08em",
  textTransform: "uppercase",
  opacity: 0.78,
  marginBottom: 10
};

const familyButtonStyle = (active: boolean): React.CSSProperties => ({
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  width: "100%",
  borderRadius: 14,
  border: active ? "1px solid rgba(72,210,255,0.60)" : "1px solid rgba(120,160,255,0.18)",
  background: active
    ? "linear-gradient(180deg, rgba(13,42,77,0.96), rgba(8,25,48,0.96))"
    : "linear-gradient(180deg, rgba(8,19,39,0.96), rgba(6,14,30,0.96))",
  padding: "12px 14px",
  cursor: "pointer",
  textAlign: "left",
  color: "inherit"
});

const chipWrapStyle: React.CSSProperties = {
  display: "flex",
  flexWrap: "wrap",
  gap: 8
};

const chipStyle = (active: boolean): React.CSSProperties => ({
  borderRadius: 999,
  border: active ? "1px solid rgba(72,210,255,0.55)" : "1px solid rgba(120,160,255,0.18)",
  background: active
    ? "linear-gradient(180deg, rgba(9,46,77,0.96), rgba(7,29,49,0.96))"
    : "rgba(8,18,37,0.92)",
  padding: "8px 12px",
  fontSize: 13,
  lineHeight: 1.2,
  cursor: "pointer",
  color: "inherit"
});

function setFamily(state: CatalogueFilterState, family: SolutionFamily): CatalogueFilterState {
  return {
    family,
    search: state.search,
    selected: {}
  };
}

function clearFamily(state: CatalogueFilterState): CatalogueFilterState {
  return {
    family: null,
    search: state.search,
    selected: {}
  };
}

function toggleGroupValue(
  state: CatalogueFilterState,
  group: FamilyFilterGroup,
  value: string
): CatalogueFilterState {
  const current = state.selected[group.id] ?? [];
  const exists = current.includes(value);

  if (group.type === "single") {
    return {
      ...state,
      selected: {
        ...state.selected,
        [group.id]: exists ? [] : [value]
      }
    };
  }

  return {
    ...state,
    selected: {
      ...state.selected,
      [group.id]: exists ? current.filter(x => x !== value) : [...current, value]
    }
  };
}

export default function SolutionFamilyFilterPanel(props: SolutionFamilyFilterPanelProps) {
  const { state, onChange } = props;
  const activeFamily = SOLUTION_FAMILIES.find(x => x.id === state.family) ?? null;

  return (
    <div style={shellStyle}>
      <section style={sectionStyle}>
        <div style={titleStyle}>Browse by Solution Family</div>

        <div style={{ display: "grid", gap: 10 }}>
          {SOLUTION_FAMILIES.map(family => {
            const active = state.family === family.id;
            return (
              <button
                key={family.id}
                type="button"
                style={familyButtonStyle(active)}
                onClick={() => onChange(active ? clearFamily(state) : setFamily(state, family.id))}
              >
                <div style={{ display: "grid", gap: 4 }}>
                  <div style={{ fontWeight: 700 }}>{family.label}</div>
                  <div style={{ fontSize: 12, opacity: 0.74 }}>{family.description}</div>
                </div>
                <div style={{ fontSize: 18, opacity: 0.8 }}>{active ? "−" : "+"}</div>
              </button>
            );
          })}
        </div>
      </section>

      {activeFamily ? (
        <section style={sectionStyle}>
          <div style={titleStyle}>{activeFamily.label} Filters</div>

          <div style={{ display: "grid", gap: 16 }}>
            {activeFamily.groups.map(group => (
              <div key={group.id} style={{ display: "grid", gap: 8 }}>
                <div style={{ fontWeight: 700, fontSize: 13 }}>{group.label}</div>

                <div style={chipWrapStyle}>
                  {group.options.map(option => {
                    const active = (state.selected[group.id] ?? []).includes(option.id);
                    return (
                      <button
                        key={option.id}
                        type="button"
                        style={chipStyle(active)}
                        onClick={() => onChange(toggleGroupValue(state, group, option.id))}
                      >
                        {option.label}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </section>
      ) : null}
    </div>
  );
}