export default function ComparisonPage() {
  return (
  <div className="wm-page" style={{ padding: 24 }}>
      <h1 style={{ fontSize: 20, fontWeight: 700 }}>Comparison</h1>
      <p style={{ opacity: 0.8, marginTop: 8 }}>
        Placeholder page restored to satisfy routing/build. Replace with real implementation.
      </p>
    </div>
  );
}

