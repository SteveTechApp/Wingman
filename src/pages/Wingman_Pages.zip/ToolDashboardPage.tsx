import React from "react";
import { useNavigate } from "react-router-dom";

type Tile = { title: string; desc: string; to: string };

function Group({ title, tiles }: { title: string; tiles: Tile[] }) {
  const nav = useNavigate();
  return (
    <div className="wm-card" style={{ display: "grid", gap: 10 }}>
      <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: 10 }}>
        <div style={{ fontWeight: 900, fontSize: 13 }}>{title}</div>
        <div style={{ opacity: 0.65, fontSize: 11 }}>{tiles.length} items</div>
      </div>

      <div className="wm-grid-2">
        {tiles.map((t) => (
          <button key={t.title} type="button" className="wm-tile" onClick={() => nav(t.to)}>
            <div className="wm-tile-title">{t.title}</div>
            <div className="wm-tile-desc">{t.desc}</div>
            <div className="wm-tile-path">{t.to}</div>
          </button>
        ))}
      </div>
    </div>
  );
}

export default function ToolDashboardPage() {
  const core: Tile[] = [
    { title: "Projects", desc: "Create/select project context.", to: "/app/projects" },
    { title: "Workspace", desc: "Active project workspace.", to: "/app/workspace" },
    { title: "Import", desc: "Upload PDF/DOCX or paste notes to extract requirements.", to: "/app/import" },
  ];

  const commercial: Tile[] = [
    { title: "Competitor Comparison", desc: "Map competitor SKUs to WyreStorm equivalents.", to: "/app/competitor-compare" },
  ];

  const tools: Tile[] = [
    { title: "Design CoPilot", desc: "Design helper workflows.", to: "/app/design-copilot" },
    { title: "Room Editor", desc: "Room editor entry.", to: "/app/room-editor" },
    { title: "Video Wall", desc: "Video wall design tool.", to: "/app/video-wall" },
  ];

  const wizards: Tile[] = [
    { title: "Customer Discovery Wizard", desc: "Capture requirements step-by-step.", to: "/app/wizard/customer-discovery" },
    { title: "Guided Project Wizard", desc: "Guided build wizard.", to: "/app/wizard/guided-project" },
  ];

  return (
    <div className="wm-page">
      <div className="wm-page-header">
        <div>
          <div className="wm-page-title">Toolbox</div>
          <div className="wm-page-sub">Single entrypoint. Grouped. No duplicated navigation.</div>
        </div>
      </div>

      <div className="wm-page-body" style={{ display: "grid", gap: 12 }}>
        <Group title="Core workflow" tiles={core} />
        <Group title="Commercial tools" tiles={commercial} />
        <Group title="Design tools" tiles={tools} />
        <Group title="Wizards" tiles={wizards} />
      </div>
    </div>
  );
}

