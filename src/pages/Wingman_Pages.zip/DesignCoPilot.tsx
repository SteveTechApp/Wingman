import React from "react";

export default function DesignCoPilot() {
  return (
  <div className="wm-page">
      <h1 className="text-2xl\ font-semibold">Design CoPilot</h1>
      <p className="mt-2\ text-sm\ opacity-80">
        Temporarily disabled for stabilisation (dependencies missing / type drift).
      </p>
    </div>
  );
}

