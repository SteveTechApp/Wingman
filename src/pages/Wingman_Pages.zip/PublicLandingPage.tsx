import "@/ui2/styles/ui2.css";

export default function PublicLandingPage() {
  return (
    <div className="ui2-root">
      <div className="wm-shell wm-shell-center">
        <div className="wm-card wm-card-lg text-center">
          <div className="wm-logo mb-6">Wingman</div>

          <div className="wm-page-title mb-2">
            AV sales and system design workspace
          </div>

          <div className="wm-muted mb-6">
            Create projects, design systems, compare competitors, and generate proposals.
          </div>

          <a href="/app/dashboard" className="wm-button wm-button-primary">
            Enter Workspace
          </a>
        </div>
      </div>
    </div>
  );
}
