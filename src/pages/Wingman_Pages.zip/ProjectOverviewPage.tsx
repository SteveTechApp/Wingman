import React, { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  getProjectsState,
  setActiveProject,
  subscribeProjects,
} from "@/state/projectsStore";

export default function ProjectOverviewPage() {
  const nav = useNavigate();
  const { id } = useParams();
  const [tick, setTick] = useState(0);

  useEffect(() => { return subscribeProjects(() => setTick(t => t + 1)); }, []);
  const s = useMemo(() => getProjectsState(), [tick]);
  const p = s.projects.find(x => x.id === id) ?? null;

  useEffect(() => {
    if (p) setActiveProject(p.id);
  }, [p?.id]);

  if (!p) {
    return (
  <div className="wm-page" style={{ display: "grid", gap: 10 }}>
        <div style={{ fontWeight: 900, fontSize: 16 }}>Project not found</div>
        <button
          type="button"
          onClick={() => nav("/app/projects")}
          style={{
            height: 34,
            width: 180,
            borderRadius: 10,
            border: "1px solid rgba(255,255,255,0.14)",
            background: "rgba(255,255,255,0.05)",
            color: "inherit",
            cursor: "pointer",
            fontWeight: 800,
            fontSize: 12,
          }}
        >
          Back to Projects
        </button>
      </div>
    );
  }

  return (
  <div className="wm-page" style={{ display: "grid", gap: 12 }}>
      <div>
        <div style={{ fontWeight: 900, fontSize: 18 }}>{p.name}</div>
        <div style={{ opacity: 0.75, fontSize: 12 }}>
          This is the project hub. Next: start from a template or wizard, then enter workspace.
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: 10 }}>
        <div style={{ padding: 12, borderRadius: 14, border: "1px solid rgba(255,255,255,0.12)", background: "rgba(255,255,255,0.03)" }}>
          <div style={{ fontSize: 11, opacity: 0.7 }}>PROJECT ID</div>
          <div style={{ fontWeight: 850, fontSize: 12, marginTop: 6 }}>{p.id}</div>
        </div>
        <div style={{ padding: 12, borderRadius: 14, border: "1px solid rgba(255,255,255,0.12)", background: "rgba(255,255,255,0.03)" }}>
          <div style={{ fontSize: 11, opacity: 0.7 }}>UPDATED</div>
          <div style={{ fontWeight: 850, fontSize: 12, marginTop: 6 }}>{new Date(p.updatedAt).toLocaleString()}</div>
        </div>
        <div style={{ padding: 12, borderRadius: 14, border: "1px solid rgba(255,255,255,0.12)", background: "rgba(255,255,255,0.03)" }}>
          <div style={{ fontSize: 11, opacity: 0.7 }}>STATUS</div>
          <div style={{ fontWeight: 850, fontSize: 12, marginTop: 6 }}>Ready</div>
        </div>
      </div>

      <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
        <button
          type="button"
          onClick={() => nav("/app/workspace")}
          style={{
            height: 34,
            padding: "0 12px",
            borderRadius: 10,
            border: "1px solid rgba(255,255,255,0.14)",
            background: "rgba(0,160,120,0.18)",
            color: "inherit",
            cursor: "pointer",
            fontWeight: 900,
            fontSize: 12,
          }}
        >
          Enter Workspace
        </button>

        <button
          type="button"
          onClick={() => nav("/app/projects")}
          style={{
            height: 34,
            padding: "0 12px",
            borderRadius: 10,
            border: "1px solid rgba(255,255,255,0.14)",
            background: "rgba(255,255,255,0.05)",
            color: "inherit",
            cursor: "pointer",
            fontWeight: 800,
            fontSize: 12,
          }}
        >
          Back to Projects
        </button>
      </div>
    </div>
  );
}

