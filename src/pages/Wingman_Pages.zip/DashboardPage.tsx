import React from "react";
import { Link } from "react-router-dom";
import { getUser } from "@/auth/auth";

export default function DashboardPage() {
  const user = getUser();

  return (
  <div className="wm-page" style={{ display: "grid", gap: 14 }}>
      <div>
        <div style={{ fontSize: 20, fontWeight: 850 }}>Your Dashboard</div>
        <div style={{ opacity: 0.82, marginTop: 4 }}>
          Welcome back{user?.name ? `, ${user.name}` : ""}. This is your personal project workspace.
        </div>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(3, minmax(0, 1fr))",
          gap: 12,
        }}
      >
        <div
          style={{
            border: "1px solid rgba(255,255,255,0.10)",
            borderRadius: 16,
            padding: 14,
            background: "rgba(255,255,255,0.04)",
          }}
        >
          <div style={{ fontWeight: 800, marginBottom: 6 }}>Quick Start</div>
          <div style={{ opacity: 0.82, fontSize: 13, lineHeight: 1.35 }}>
            Jump straight into the tools.
          </div>
          <div style={{ marginTop: 10, display: "grid", gap: 8 }}>
            <Link to="/app/room-editor" style={{ color: "inherit", opacity: 0.9 }}>
              → Room Editor
            </Link>
            <Link to="/app/comparison" style={{ color: "inherit", opacity: 0.9 }}>
              → Competitor Comparison
            </Link>
          </div>
        </div>

        <div
          style={{
            border: "1px solid rgba(255,255,255,0.10)",
            borderRadius: 16,
            padding: 14,
            background: "rgba(255,255,255,0.04)",
          }}
        >
          <div style={{ fontWeight: 800, marginBottom: 6 }}>Projects</div>
          <div style={{ opacity: 0.82, fontSize: 13, lineHeight: 1.35 }}>
            This area is ready for your real project list (saved designs, proposals, drafts).
          </div>
          <div style={{ marginTop: 10, opacity: 0.7, fontSize: 12 }}>
            (Next step: wire to storage / database)
          </div>
        </div>

        <div
          style={{
            border: "1px solid rgba(255,255,255,0.10)",
            borderRadius: 16,
            padding: 14,
            background: "rgba(255,255,255,0.04)",
          }}
        >
          <div style={{ fontWeight: 800, marginBottom: 6 }}>Activity</div>
          <div style={{ opacity: 0.82, fontSize: 13, lineHeight: 1.35 }}>
            Placeholder for recent tools, recent routes, and latest generated outputs.
          </div>
        </div>
      </div>
    </div>
  );
}

