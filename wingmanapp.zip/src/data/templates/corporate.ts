
import { v4 as uuidv4 } from 'uuid';
import { UserTemplate } from '../../utils/types';

export const CORPORATE_TEMPLATES: UserTemplate[] = [
    // --- HUDDLE ROOMS ---
    {
        templateId: uuidv4(),
        conceptId: 'huddle-room',
        conceptName: 'Huddle Room',
        templateName: 'Wired Huddle Space',
        description: 'A simple, cost-effective huddle space for 3-4 people with wired connectivity and a basic webcam.',
        vertical: 'corp',
        roomData: {
            id: '', roomName: 'Huddle Space', roomType: 'Huddle Space', designTier: 'Bronze',
            dimensions: { length: 4, width: 3, height: 2.7 }, maxParticipants: 4,
            ioRequirements: [
                { id: uuidv4(), name: 'Table Input', deviceType: 'Laptop', type: 'input', quantity: 1, connectionType: 'HDMI', distributionType: 'Direct', distance: 2, terminationType: 'Table Box', control: { needed: false, types: [] } },
                { id: uuidv4(), name: 'Room Display', deviceType: 'Room Display', type: 'output', quantity: 1, connectionType: 'HDMI', distributionType: 'Direct', distance: 5, terminationType: 'Wall Mount', control: { needed: false, types: [] } },
            ],
            displayType: 'single', displayCount: 1,
            features: [{ name: 'Video Conferencing', priority: 'must-have' }],
            functionalityStatement: 'A budget-friendly huddle room. The SW-0201-4K auto-switcher allows users to easily connect a laptop via HDMI or USB-C. A generic USB webcam mounted on the display provides basic video conferencing capabilities. Audio is handled by the display speakers and the laptop microphone.',
            manuallyAddedEquipment: [
                { sku: 'SW-0201-4K', name: '2x1 USB-C & HDMI Wireless Switcher', quantity: 1, category: 'Presentation Switcher', description: 'A compact 2x1 presentation switcher with HDMI and USB-C inputs and wireless casting support.', tags: ['Switcher', 'USB-C', 'Casting', '4K', 'Bronze', 'HDMI', 'Auto-switching', '2x1'] },
                { sku: 'GEN-USB-CAM', name: 'Generic 4K USB Webcam', quantity: 1, category: 'Camera', description: 'A high-quality 4K USB webcam.', tags: ['Camera', 'USB', '4K', 'Webcam'] },
            ],
            constructionDetails: { wallConstruction: 'drywall', cableContainment: 'trunking', furnitureType: 'fixed' },
            audioSystemDetails: { speakerLayout: 'none', systemType: 'low_impedance', useCases: ['video_conferencing'], microphoneType: 'none', ucCompatibility: true },
            technicalDetails: { primaryVideoResolution: '4K/30Hz 4:4:4', videoSignalTypes: ['HDMI', 'USB-C'], controlSystem: 'None (Auto-switching)', cameraType: 'usb_webcam', cameraCount: 1, roomPc: false },
        },
    },
    {
        templateId: uuidv4(),
        conceptId: 'huddle-room',
        conceptName: 'Huddle Room',
        templateName: 'BYOM Huddle Room',
        description: 'A professional BYOM room for up to 6 people with an all-in-one speakerphone/switcher.',
        vertical: 'corp',
        roomData: {
            id: '', roomName: 'Huddle Room 101', roomType: 'Huddle Space', designTier: 'Silver',
            dimensions: { length: 6, width: 4, height: 2.7 }, maxParticipants: 6,
            ioRequirements: [
                { id: uuidv4(), name: 'Table USB-C', deviceType: 'Laptop', type: 'input', quantity: 1, connectionType: 'USB-C', distributionType: 'Direct', distance: 2, terminationType: 'Table Box', control: { needed: false, types: [] } },
                { id: uuidv4(), name: 'Room Display', deviceType: 'Room Display', type: 'output', quantity: 1, connectionType: 'HDMI', distributionType: 'Direct', distance: 5, terminationType: 'Wall Mount', control: { needed: false, types: [] } },
            ],
            displayType: 'single', displayCount: 1,
            features: [
                { name: 'Video Conferencing', priority: 'must-have' },
                { name: 'Wireless Presentation', priority: 'nice-to-have' },
            ],
            functionalityStatement: 'An entry-level meeting room designed for Bring Your Own Meeting (BYOM). The APO-210-UC provides a 2-input switcher, a powerful speakerphone with echo cancellation, and USB for a room camera. Users can connect their laptop to run a video call using the room\'s AV.',
            manuallyAddedEquipment: [
                { sku: 'APO-210-UC', name: 'Apollo 210 UC Speakerphone & Switcher', quantity: 1, category: 'Unified Communications', description: 'A complete BYOM solution with USB-C and HDMI inputs, speakerphone with AEC, and dual-view output for medium conference rooms.', tags: ['UC', 'BYOM', 'USB-C', 'Speakerphone', 'Dual-View', 'HDMI', 'AEC'] },
                { sku: 'CAM-100-4K', name: '4K USB ePTZ Camera', quantity: 1, category: 'Camera', description: 'A compact 4K USB camera with a wide 120-degree field of view and ePTZ.', tags: ['Camera', 'USB', '4K', 'Webcam', 'ePTZ'] },
            ],
            constructionDetails: { wallConstruction: 'drywall', cableContainment: 'trunking', furnitureType: 'fixed' },
            audioSystemDetails: { speakerLayout: 'soundbar', systemType: 'low_impedance', useCases: ['video_conferencing'], microphoneType: 'soundbar_mic', ucCompatibility: true },
            technicalDetails: { primaryVideoResolution: '4K/30Hz 4:4:4', videoSignalTypes: ['HDMI', 'USB-C'], controlSystem: 'None (Auto-switching)', cameraType: 'usb_webcam', cameraCount: 1, roomPc: false },
        },
    },
    {
        templateId: uuidv4(),
        conceptId: 'huddle-room',
        conceptName: 'Huddle Room',
        templateName: 'Premium Dual-Screen Huddle',
        description: 'A high-performance huddle room with dual displays, wireless casting, and auto-tracking camera.',
        vertical: 'corp',
        roomData: {
            id: '', roomName: 'Executive Huddle', roomType: 'Huddle Space', designTier: 'Gold',
            dimensions: { length: 6, width: 5, height: 2.7 }, maxParticipants: 6,
            ioRequirements: [
                { id: uuidv4(), name: 'Table USB-C', deviceType: 'Laptop', type: 'input', quantity: 1, connectionType: 'USB-C', distributionType: 'Direct', distance: 2, terminationType: 'Table Box', control: { needed: false, types: [] } },
                { id: uuidv4(), name: 'Left Display', deviceType: 'Room Display', type: 'output', quantity: 1, connectionType: 'HDMI', distributionType: 'Direct', distance: 5, terminationType: 'Wall Mount', control: { needed: false, types: [] } },
                { id: uuidv4(), name: 'Right Display', deviceType: 'Room Display', type: 'output', quantity: 1, connectionType: 'HDMI', distributionType: 'Direct', distance: 5, terminationType: 'Wall Mount', control: { needed: false, types: [] } },
            ],
            displayType: 'dual_display', displayCount: 2,
            features: [{ name: 'Video Conferencing', priority: 'must-have' }, { name: 'Wireless Presentation', priority: 'must-have' }],
            functionalityStatement: 'A premium huddle experience with dual displays to show people and content simultaneously. The SW-640L-TX-W switcher handles USB-C and wireless casting (BYOM) with the APO-DG2 dongle. An AI-tracking camera automatically frames the participants.',
            manuallyAddedEquipment: [
                { sku: 'SW-640L-TX-W', name: '6-Input 4K/60Hz Presentation Switcher', quantity: 1, category: 'Presentation Switcher', description: 'Dual output 4K presentation switcher with wireless casting, USB-C, and USB host.', tags: ['Switcher', 'USB-C', 'Casting', '4K', 'Gold', '6x2'] },
                { sku: 'APO-DG2', name: 'Apollo USB-C/HDMI Wireless Casting Dongle', quantity: 1, category: 'Unified Communications', description: 'Wireless casting dongle with USB data support for BYOM.', tags: ['UC', 'Casting', 'Wireless'] },
                { sku: 'CAM-210-PTZ', name: '4K AI Tracking PTZ Camera', quantity: 1, category: 'Camera', description: 'Professional PTZ camera with AI tracking.', tags: ['Camera', 'PTZ', '4K', 'AI Tracking'] },
                { sku: 'HALO 80', name: 'USB/Bluetooth Speakerphone', quantity: 1, category: 'Unified Communications', description: 'Omni-Direction 4Mics | AEC', tags: ['UC', 'Speakerphone', 'USB'] },
            ],
            constructionDetails: { wallConstruction: 'glass', cableContainment: 'floor_boxes', furnitureType: 'fixed' },
            audioSystemDetails: { speakerLayout: 'none', systemType: 'low_impedance', useCases: ['video_conferencing'], microphoneType: 'table_mic', ucCompatibility: true },
            technicalDetails: { primaryVideoResolution: '4K/60Hz 4:4:4', videoSignalTypes: ['HDMI', 'USB-C'], controlSystem: 'Touch Panel', cameraType: 'hdmi_ptz', cameraCount: 1, roomPc: false },
        },
    },

    // --- CONFERENCE ROOMS ---
    {
        templateId: uuidv4(),
        conceptId: 'conference-room',
        conceptName: 'Conference Room',
        templateName: 'Standard Conference Room',
        description: 'A cost-effective room with essential connectivity for simple presentations.',
        vertical: 'corp',
        roomData: {
            id: '', roomName: 'Conference Room', roomType: 'Conference Room', designTier: 'Bronze',
            dimensions: { length: 9, width: 5, height: 2.8 }, maxParticipants: 10,
            ioRequirements: [
                { id: uuidv4(), name: 'Table Input', deviceType: 'Laptop', type: 'input', quantity: 1, connectionType: 'HDMI', distributionType: 'Direct', distance: 2, terminationType: 'Table Box', control: { needed: false, types: [] } },
                { id: uuidv4(), name: 'Room Display', deviceType: 'Room Display', type: 'output', quantity: 1, connectionType: 'HDMI', distributionType: 'Direct', distance: 5, terminationType: 'Wall Mount', control: { needed: false, types: [] } },
            ],
            displayType: 'single', displayCount: 1, features: [],
            functionalityStatement: 'A basic conference room with an auto-switcher for HDMI and USB-C sources. The signal is sent to a single 4K display. Audio is handled by the display speakers. This is a simple, plug-and-present solution.',
            manuallyAddedEquipment: [
                { sku: 'SW-0201-4K', name: '2x1 USB-C & HDMI Wireless Switcher', quantity: 1, category: 'Presentation Switcher', description: 'A compact 2x1 presentation switcher with HDMI and USB-C inputs and wireless casting support.', tags: ['Switcher', 'USB-C', 'Casting', '4K', 'Bronze', 'HDMI', 'Auto-switching', '2x1'] },
            ],
            constructionDetails: { wallConstruction: 'drywall', cableContainment: 'trunking', furnitureType: 'fixed' },
            audioSystemDetails: { speakerLayout: 'none', systemType: 'low_impedance', useCases: [], microphoneType: 'none', ucCompatibility: false },
            technicalDetails: { primaryVideoResolution: '1080p', videoSignalTypes: ['HDMI', 'USB-C'], controlSystem: 'None (Auto-switching)', cameraType: 'none', cameraCount: 0, roomPc: false },
        },
    },
    {
        templateId: uuidv4(),
        conceptId: 'conference-room',
        conceptName: 'Conference Room',
        templateName: 'Collaboration Space',
        description: 'A versatile VC-enabled room for 8-10 people with HDBaseT extension and USB host for peripherals.',
        vertical: 'corp',
        roomData: {
            id: '', roomName: 'Conference Room 205', roomType: 'Conference Room', designTier: 'Silver',
            dimensions: { length: 9, width: 5, height: 2.8 }, maxParticipants: 10,
            ioRequirements: [
                { id: uuidv4(), name: 'Table USB-C', deviceType: 'Laptop', type: 'input', quantity: 1, connectionType: 'USB-C', distributionType: 'Direct', distance: 2, terminationType: 'Table Box', control: { needed: false, types: [] } },
                { id: uuidv4(), name: 'Table HDMI', deviceType: 'Laptop', type: 'input', quantity: 1, connectionType: 'HDMI', distributionType: 'Direct', distance: 2, terminationType: 'Table Box', control: { needed: false, types: [] } },
                { id: uuidv4(), name: 'Room Display', deviceType: 'Room Display', type: 'output', quantity: 1, connectionType: 'HDMI', distributionType: 'HDBaseT', distance: 20, terminationType: 'Wall Mount', control: { needed: false, types: [] } },
            ],
            displayType: 'single', displayCount: 1,
            features: [{ name: 'Video Conferencing', priority: 'must-have' }, { name: 'Wireless Presentation', priority: 'nice-to-have' }],
            functionalityStatement: 'A flexible conference room for modern collaboration. The SW-340-TX HDBaseT presentation switcher offers multiple inputs including USB-C and sends the signal over a long distance to the display. Its built-in USB host integrates a room camera and speakerphone for a seamless BYOM experience.',
            manuallyAddedEquipment: [
                { sku: 'SW-340-TX', name: '3-Input HDBaseT Presentation Switcher with USB-C', quantity: 1, category: 'Presentation Switcher', description: 'A versatile 3-input presentation switcher with 2x HDMI and 1x USB-C inputs. Features an HDBaseT output for long-distance transmission to a display, USB host, and auto-switching.', tags: ['Switcher', 'HDBaseT', 'USB-C', '4K', 'Silver', '3x1', 'USB Host', 'Auto-switching'] },
                { sku: 'HALO 80', name: 'USB/Bluetooth Speakerphone', quantity: 1, category: 'Unified Communications', description: 'Daisy-chain up to 9 units | Omni-Direction 4Mics | AEC | Noise Reduction | 3W speaker | USB2.0', tags: ['UC', 'Speakerphone', 'Bluetooth', 'USB', 'AEC', 'Daisy-chain'] },
                { sku: 'GEN-USB-CAM', name: 'Generic 4K USB Webcam', quantity: 1, category: 'Camera', description: 'A high-quality 4K USB webcam.', tags: ['Camera', 'USB', '4K', 'Webcam'] },
            ],
            constructionDetails: { wallConstruction: 'drywall', cableContainment: 'floor_boxes', furnitureType: 'fixed' },
            audioSystemDetails: { speakerLayout: 'soundbar', systemType: 'low_impedance', useCases: ['video_conferencing'], microphoneType: 'soundbar_mic', ucCompatibility: true },
            technicalDetails: { primaryVideoResolution: '4K/60Hz 4:4:4', videoSignalTypes: ['HDMI', 'USB-C'], controlSystem: 'Simple Keypad', cameraType: 'usb_webcam', cameraCount: 1, roomPc: false },
        },
    },
    {
        templateId: uuidv4(),
        conceptId: 'conference-room',
        conceptName: 'Conference Room',
        templateName: 'Advanced Conference Room',
        description: 'A high-performance room with dual displays, wireless BYOM, and advanced control.',
        vertical: 'corp',
        roomData: {
            id: '', roomName: 'Conference Room', roomType: 'Conference Room', designTier: 'Gold',
            dimensions: { length: 9, width: 5, height: 2.8 }, maxParticipants: 10,
            ioRequirements: [
                { id: uuidv4(), name: 'Table USB-C', deviceType: 'Laptop', type: 'input', quantity: 1, connectionType: 'USB-C', distributionType: 'Direct', distance: 2, terminationType: 'Table Box', control: { needed: false, types: [] } },
                { id: uuidv4(), name: 'Left Display', deviceType: 'Room Display', type: 'output', quantity: 1, connectionType: 'HDMI', distributionType: 'Direct', distance: 5, terminationType: 'Wall Mount', control: { needed: false, types: [] } },
                { id: uuidv4(), name: 'Right Display', deviceType: 'Room Display', type: 'output', quantity: 1, connectionType: 'HDMI', distributionType: 'Direct', distance: 7, terminationType: 'Wall Mount', control: { needed: false, types: [] } },
            ],
            displayType: 'dual_display', displayCount: 2,
            features: [ { name: 'Video Conferencing', priority: 'must-have' }, { name: 'Wireless Presentation', priority: 'must-have' } ],
            functionalityStatement: 'A premium conference room with a powerful SW-640L-TX-W switcher driving two independent 4K displays. It supports full BYOM with wireless casting and USB peripheral sharing. A dedicated DSP and ceiling mics provide superior audio.',
            manuallyAddedEquipment: [
                { sku: 'SW-640L-TX-W', name: '6-Input 4K/60Hz Presentation Switcher with USB-C & Wireless Casting', quantity: 1, category: 'Presentation Switcher', description: 'Dual output 4K presentation switcher with wireless casting, USB-C, and USB host for peripherals.', tags: ['Switcher', 'USB-C', 'Casting', '4K', 'Gold', '6x2', 'Dual Output', 'USB Host', 'BYOM', 'Wireless'] },
                { sku: 'APO-DG2', name: 'Apollo USB-C/HDMI Wireless Casting Dongle (for -W SKUs)', quantity: 1, category: 'Unified Communications', description: 'Wireless casting dongle with USB data support for BYOM.', tags: ['UC', 'Casting', 'Wireless', 'USB-C', 'HDMI', 'Dongle', 'BYOM', 'USB'] },
                { sku: 'COM-MIC-HUB', name: 'Microphone Hub | Microphone Mixer', quantity: 1, category: 'Audio Processor', description: 'AEC & AGC & ANR | Web-UI', tags: ['DSP', 'Microphone', 'Mixer', 'AEC', 'AGC'] },
            ],
            constructionDetails: { wallConstruction: 'drywall', cableContainment: 'floor_boxes', furnitureType: 'fixed' },
            audioSystemDetails: { speakerLayout: 'in_ceiling', systemType: 'high_impedance', useCases: ['video_conferencing'], microphoneType: 'ceiling_mic', ucCompatibility: true },
            technicalDetails: { primaryVideoResolution: '4K/60Hz 4:4:4', videoSignalTypes: ['HDMI', 'USB-C'], controlSystem: 'Touch Panel', cameraType: 'hdmi_ptz', cameraCount: 1, roomPc: false },
        },
    },

    // --- BOARDROOMS ---
    {
        templateId: uuidv4(),
        conceptId: 'boardroom',
        conceptName: 'Executive Boardroom',
        templateName: 'Essential Boardroom',
        description: 'A robust boardroom setup with a reliable wired presentation system and HDBaseT extension.',
        vertical: 'corp',
        roomData: {
            id: '', roomName: 'Boardroom A', roomType: 'Boardroom', designTier: 'Bronze',
            dimensions: { length: 10, width: 6, height: 3 }, maxParticipants: 12,
            ioRequirements: [
                { id: uuidv4(), name: 'Table Input', deviceType: 'Laptop', type: 'input', quantity: 2, connectionType: 'HDMI', distributionType: 'Direct', distance: 2, terminationType: 'Table Box', control: { needed: false, types: [] } },
                { id: uuidv4(), name: 'Projector', deviceType: 'Projector', type: 'output', quantity: 1, connectionType: 'HDMI', distributionType: 'HDBaseT', distance: 15, terminationType: 'Ceiling Mount', control: { needed: false, types: [] } },
            ],
            displayType: 'projector', displayCount: 1,
            features: [{ name: 'Speech Reinforcement', priority: 'nice-to-have' }],
            functionalityStatement: 'A reliable and straightforward boardroom system. A SW-510-TX switcher provides connectivity for HDMI and VGA sources at the table. The signal is extended via HDBaseT to a ceiling-mounted projector. Control is simplified through auto-switching, ensuring meetings start on time without technical hassle.',
            manuallyAddedEquipment: [
                { sku: 'SW-510-TX', name: '5-Input 4K HDBaseT Presentation Switcher', quantity: 1, category: 'Presentation Switcher', description: '5-input HDBaseT/HDMI/VGA/DP switcher.', tags: ['HDBaseT', '4K', 'Switcher', 'CEC', 'Silver', '5x1', 'HDMI', 'VGA'] },
            ],
            constructionDetails: { wallConstruction: 'drywall', cableContainment: 'floor_boxes', furnitureType: 'fixed' },
            audioSystemDetails: { speakerLayout: 'in_ceiling', systemType: 'low_impedance', useCases: ['program_audio'], microphoneType: 'none', ucCompatibility: false },
            technicalDetails: { primaryVideoResolution: '4K/30Hz 4:4:4', videoSignalTypes: ['HDMI', 'VGA'], controlSystem: 'None (Auto-switching)', cameraType: 'none', cameraCount: 0, roomPc: false },
        },
    },
    {
        templateId: uuidv4(),
        conceptId: 'boardroom',
        conceptName: 'Executive Boardroom',
        templateName: 'Dual-Display Boardroom',
        description: 'A matrix-based system driving two displays for flexible content presentation and collaboration.',
        vertical: 'corp',
        roomData: {
            id: '', roomName: 'Boardroom B', roomType: 'Boardroom', designTier: 'Silver',
            dimensions: { length: 10, width: 6, height: 3 }, maxParticipants: 12,
            ioRequirements: [
                { id: uuidv4(), name: 'Table HDMI', deviceType: 'Laptop', type: 'input', quantity: 4, connectionType: 'HDMI', distributionType: 'Direct', distance: 2, terminationType: 'Table Box', control: { needed: false, types: [] } },
                { id: uuidv4(), name: 'Displays', deviceType: 'Room Display', type: 'output', quantity: 2, connectionType: 'HDMI', distributionType: 'Direct', distance: 10, terminationType: 'Wall Mount', control: { needed: false, types: [] } },
            ],
            displayType: 'dual_display', displayCount: 2,
            features: [{ name: 'Multi-Display Support', priority: 'must-have' }],
            functionalityStatement: 'A productive boardroom environment with dual displays, allowing participants to view video participants on one screen and shared content on the other. The MX-0402-H2-MST matrix switcher enables any of the 4 table inputs to be routed to either display, offering versatile presentation modes like independent viewing or mirroring.',
            manuallyAddedEquipment: [
                { sku: 'MX-0402-H2-MST', name: '4x2 4K Matrix with Multi-View Scaling', quantity: 1, category: 'Matrix Switcher', description: '4x2 4K matrix switcher with multi-view and scaling capabilities.', tags: ['Matrix', 'Multiview', '4K', 'Silver', '4x2', 'Scaling'] },
                { sku: 'CAB-HAOC-10', name: 'Essentials 10m 4K/60Hz 4:4:4 Active Optical HDMI Cable', quantity: 2, category: 'Cable', description: 'Active optical cable.', tags: ['Cable', 'HDMI', 'AOC'] },
            ],
            constructionDetails: { wallConstruction: 'glass', cableContainment: 'floor_boxes', furnitureType: 'fixed' },
            audioSystemDetails: { speakerLayout: 'soundbar', systemType: 'low_impedance', useCases: ['program_audio'], microphoneType: 'none', ucCompatibility: false },
            technicalDetails: { primaryVideoResolution: '4K/60Hz 4:4:4', videoSignalTypes: ['HDMI'], controlSystem: 'Simple Keypad', cameraType: 'none', cameraCount: 0, roomPc: false },
        },
    },
     {
        templateId: uuidv4(),
        conceptId: 'boardroom',
        conceptName: 'Executive Boardroom',
        templateName: 'Executive Boardroom Suite',
        description: 'A high-performance system for a large boardroom with dual displays, wireless BYOM, advanced audio, and touch panel control.',
        vertical: 'corp',
        roomData: {
            id: '',
            roomName: 'Executive Boardroom',
            roomType: 'Boardroom',
            designTier: 'Gold',
            dimensions: { length: 12, width: 6, height: 3 },
            maxParticipants: 16,
            ioRequirements: [
                { id: uuidv4(), name: 'Table Input 1 (USB-C)', deviceType: 'Laptop', type: 'input', quantity: 1, connectionType: 'USB-C', distributionType: 'Direct', distance: 2, terminationType: 'Table Box', control: { needed: false, types: [] } },
                { id: uuidv4(), name: 'Left Display', deviceType: 'Room Display', type: 'output', quantity: 1, connectionType: 'HDMI', distributionType: 'Direct', distance: 5, terminationType: 'Wall Mount', control: { needed: true, types: ['IR'] } },
                { id: uuidv4(), name: 'Right Display', deviceType: 'Room Display', type: 'output', quantity: 1, connectionType: 'HDMI', distributionType: 'Direct', distance: 7, terminationType: 'Wall Mount', control: { needed: true, types: ['IR'] } },
            ],
            displayType: 'dual_display',
            displayCount: 2,
            features: [
                { name: 'Video Conferencing', priority: 'must-have' },
                { name: 'Wireless Presentation', priority: 'must-have' },
            ],
            functionalityStatement: 'A premium boardroom with a powerful SW-640L-TX-W presentation switcher driving two 4K displays independently. The included APO-DG2 dongle provides a full BYOM wireless casting experience. A discrete PTZ camera and ceiling microphones provide crystal-clear conferencing, all managed via a SYN-TOUCH10 touch panel.',
            manuallyAddedEquipment: [
                { sku: 'SW-640L-TX-W', name: '6-Input 4K/60Hz Presentation Switcher with USB-C & Wireless Casting', quantity: 1, category: 'Presentation Switcher', description: 'Dual output 4K presentation switcher with wireless casting, USB-C, and USB host for peripherals.', tags: ['Switcher', 'USB-C', 'Casting', '4K', 'Gold', '6x2', 'Dual Output', 'USB Host', 'BYOM', 'Wireless'] },
                { sku: 'APO-DG2', name: 'Apollo USB-C/HDMI Wireless Casting Dongle (for -W SKUs)', quantity: 1, category: 'Unified Communications', description: 'Wireless casting dongle with USB data support for BYOM.', tags: ['UC', 'Casting', 'Wireless', 'USB-C', 'HDMI', 'Dongle', 'BYOM', 'USB'] },
                { sku: 'GEN-PTZ-CAM', name: 'Generic 4K PTZ Camera', quantity: 1, category: 'Camera', description: 'A professional 4K pan-tilt-zoom camera with 12x optical zoom, USB, and IP streaming.', tags: ['Camera', 'PTZ', '4K', 'USB', '12x Zoom', 'USB3.0', 'IP Stream', 'HDMI'] },
                { sku: 'COM-MIC-HUB', name: 'Microphone Hub | Microphone Mixer', quantity: 1, category: 'Audio Processor', description: 'AEC & AGC & ANR | Web-UI', tags: ['DSP', 'Microphone', 'Mixer', 'AEC', 'AGC'] },
                { sku: 'SYN-TOUCH10', name: 'Synergy™ 10.1” All-in-One Touchpad IP Controller', quantity: 1, category: 'Control', description: 'PoE+ | Table Top Stand & Wall-Mount (US/UK/EU Compatible)', tags: ['Control', 'Touchscreen', 'Synergy'] },
            ],
            constructionDetails: { wallConstruction: 'drywall', cableContainment: 'floor_boxes', furnitureType: 'fixed' },
            audioSystemDetails: { speakerLayout: 'in_ceiling', systemType: 'low_impedance', useCases: ['speech_reinforcement', 'video_conferencing'], microphoneType: 'ceiling_mic', ucCompatibility: true },
            technicalDetails: { primaryVideoResolution: '4K/60Hz 4:4:4', videoSignalTypes: ['HDMI', 'USB-C'], controlSystem: 'Touch Panel', cameraType: 'hdmi_ptz', cameraCount: 1, roomPc: false },
        },
    }
];



