
/* Auto-generated. Do not edit manually. */
export type WyreStormSkuItem = { sku: string; description: string; family: string; tier: string };
export type WyreStormSkuCatalog = { version: string; source: string; generatedAt: string; count: number; items: WyreStormSkuItem[] };
const catalog: WyreStormSkuCatalog = {
  "version": "2026",
  "source": "2026 Wyrestorm SKU (1).xlsx",
  "generatedAt": "2026-01-28T08:09:35.681Z",
  "count": 154,
  "items": [
    {
      "sku": "AMP-260-DNT",
      "description": "120W Network Amplifier | 2 x 60w or 4 x 25w Channel Output @ 4ohm | Dual Power Options | Advanced DSP with Dante Integration",
      "family": "AMP",
      "tier": "Unclassified"
    },
    {
      "sku": "APO-210-UC",
      "description": "Apollo™ Video-speakerphone switcher |USB-C & HDMI input  | HDMI Out & HDBaseT™ Out  |10W Speaker | Omni-direction 4xMics | Dual-View | Airplay & Miracast & APO-DG1 dongle",
      "family": "APO",
      "tier": "Unclassified"
    },
    {
      "sku": "APO-COM-MIC",
      "description": "Apollo™ companion mic | MINI USB connection | Mounting on table",
      "family": "APO",
      "tier": "Unclassified"
    },
    {
      "sku": "APO-DG-DOCK",
      "description": "Docking station for APO-DG1, APO-DG2 & APO-DG-HDMI",
      "family": "APO",
      "tier": "Unclassified"
    },
    {
      "sku": "APO-DG-HDMI",
      "description": "HDMI – USB C Adapter for the APO-DG1/2",
      "family": "APO",
      "tier": "Unclassified"
    },
    {
      "sku": "APO-DG1",
      "description": "Apollo™  1080p USB-C(DP Atl mode) dongle for wireless casting",
      "family": "APO",
      "tier": "Unclassified"
    },
    {
      "sku": "APO-DG2",
      "description": "Apollo™  4K USB-C(DP Atl mode) dongle for wireless casting and wireless conferencing( with APP)",
      "family": "APO",
      "tier": "Unclassified"
    },
    {
      "sku": "APO-DG2-PRO",
      "description": "Apollo™  4K USB-C(DP Atl mode) dongle for wireless casting and wireless conferencing( without APP)",
      "family": "APO",
      "tier": "Unclassified"
    },
    {
      "sku": "APO-MIC-EXT",
      "description": "Mini-USB to Ethernet adaptor for connection between Videobar and  Companion Mic APO-COM-MIC",
      "family": "APO",
      "tier": "Unclassified"
    },
    {
      "sku": "APO-SKY-MIC",
      "description": "Apollo™ companion  Add-On Ceiling Mic | RJ45 connection",
      "family": "APO",
      "tier": "Unclassified"
    },
    {
      "sku": "APO-VX20-MNT",
      "description": "Wall Mounting Kit for the APO-VX20-UC Video Bar",
      "family": "APO",
      "tier": "Unclassified"
    },
    {
      "sku": "APO-VX20-UC",
      "description": "Apollo™  Video Bar & Switcher | USB-C & HDMI input | HDMI Output |  4K AI camera | 120° DFOV | Auto Framing and Presenter Tracking|Dual 8w stereo Speakers | Airplay & Miracast & APO-DG1，ZOOM Certification",
      "family": "APO",
      "tier": "Unclassified"
    },
    {
      "sku": "CAB-HAOC-10",
      "description": "10m/32ft HDMI 2.0 AOC | 24Gbps | 4K60Hz | Dolby Vision & HDR | ARC, CEC, ALLM & VRR | ISF Certified | FT4, CL3",
      "family": "CAB",
      "tier": "Unclassified"
    },
    {
      "sku": "CAB-HAOC-15",
      "description": "15m/49ft HDMI 2.0 AOC | 24Gbps | 4K60Hz | Dolby Vision & HDR | ARC, CEC, ALLM & VRR | ISF Certified | FT4, CL4",
      "family": "CAB",
      "tier": "Unclassified"
    },
    {
      "sku": "CAB-HAOC-15-C",
      "description": "15m/49ft HDMI 2.0 AOC | Detachable Head | 24Gbps | 4K60Hz | Dolby Vision & HDR | ARC, CEC, ALLM & VRR | ISF Certified | CPR",
      "family": "CAB",
      "tier": "Unclassified"
    },
    {
      "sku": "CAB-HAOC-20",
      "description": "20m/65ft HDMI 2.0 AOC | 24Gbps | 4K60Hz | Dolby Vision & HDR | ARC, CEC, ALLM & VRR | ISF Certified | FT4, CL5",
      "family": "CAB",
      "tier": "Unclassified"
    },
    {
      "sku": "CAB-HAOC-20-C",
      "description": "20m/65ft HDMI 2.0 AOC | Detachable Head | 24Gbps | 4K60Hz | Dolby Vision & HDR | ARC, CEC, ALLM & VRR | ISF Certified | CPR",
      "family": "CAB",
      "tier": "Unclassified"
    },
    {
      "sku": "CAB-HAOC-30-C",
      "description": "30m/98ft HDMI 2.0 AOC | Detachable Head | 24Gbps | 4K60Hz | Dolby Vision & HDR | ARC, CEC, ALLM & VRR | ISF Certified | CPR",
      "family": "CAB",
      "tier": "Unclassified"
    },
    {
      "sku": "CAB-HAOC-FRL-10",
      "description": "10m/32ft HDMI 2.1 AOC | 48Gbps | 8K60Hz | Dolby Vision & HDR | eARC, CEC, ALLM & VRR | ISF Certified | UHS Certified",
      "family": "CAB",
      "tier": "Unclassified"
    },
    {
      "sku": "CAB-HAOC-FRL-15",
      "description": "15m/49ft HDMI 2.1 AOC | 48Gbps | 8K60Hz | Dolby Vision & HDR | eARC, CEC, ALLM & VRR | ISF Certified | UHS Certified",
      "family": "CAB",
      "tier": "Unclassified"
    },
    {
      "sku": "CAB-UAOC-15-C",
      "description": "USB 3.2 M to F Active Optical Extension Cable | 10Gbps Superspeed+ | CPR Rated (15m/49ft)",
      "family": "CAB",
      "tier": "Unclassified"
    },
    {
      "sku": "CAB-USBC-15",
      "description": "USB-C to C Active Optical Cable | 5Gbps Superspeed | 4K60 Alt-Mode | 60W PD | Screw-Lock Connector (15m/49ft)",
      "family": "CAB",
      "tier": "Unclassified"
    },
    {
      "sku": "CAM-210-NDI-PTZ",
      "description": "1080p60 PTZ Camera | USB 3.0 | Network Streaming | 12x optical zoom | A.I. Auto-Framing | HDMI Out | NDI",
      "family": "CAM",
      "tier": "Unclassified"
    },
    {
      "sku": "CAM-210-PTZ",
      "description": "1080p60 PTZ Camera | USB 3.0 | Network Streaming | 12x optical zoom | A.I. Auto-Framing | HDMI Out",
      "family": "CAM",
      "tier": "Unclassified"
    },
    {
      "sku": "COM-MIC-HUB",
      "description": "Microphone Hub | Microphone Mixer | AEC & AGC & ANR | Web-UI",
      "family": "COM",
      "tier": "Unclassified"
    },
    {
      "sku": "EX-100-G2",
      "description": "4K60Hz 4:2:0 HDBaseT Extender | PoH | CEC | IR | RS232 | 100m/327ft",
      "family": "EX",
      "tier": "Unclassified"
    },
    {
      "sku": "EX-100-H2",
      "description": "4K60Hz 4:2:0  HDBT 2.0 Extender Set | PoH | USB 2.0 |Analog Audio & RS-232 Passthrough (4K: 100m/328ft)",
      "family": "EX",
      "tier": "Unclassified"
    },
    {
      "sku": "EX-100-IW-USBC",
      "description": "USB 3.2 Single Gang In-Wall HDBT-USB3 Transmitter and Receiver Kit | 100m | PoH+| 5Gbps | 4 USB-A ports",
      "family": "EX",
      "tier": "Unclassified"
    },
    {
      "sku": "EX-100-KVM",
      "description": "4K60Hz 4:2:0  HDBT 2.0 Extender Set | PoH | USB 2.0 |Analog Audio & RS-232 Passthrough (4K: 100m/328ft)",
      "family": "EX",
      "tier": "Unclassified"
    },
    {
      "sku": "EX-100-KVM-IP",
      "description": "4K30Hz 4:4:4 IP Extender set | 1GbE | Zero latency | USB2.0 | Multi-Channel audio (4K30: 100m/328ft)",
      "family": "EX",
      "tier": "Unclassified"
    },
    {
      "sku": "EX-100-USB3",
      "description": "USB 3.2 HDBT-USB3 Extender | 100m | PoH+| 5Gbps | 4 USB-A ports",
      "family": "EX",
      "tier": "Unclassified"
    },
    {
      "sku": "EX-35-H2",
      "description": "4K60Hz 4:4:4 HDBaseT™ Extender Set | Dolby Vision & HDR | PoH | RS232 & 2-Way IR Passthrough (4K: 35m/115ft, 1080p: 70m/230ft)",
      "family": "EX",
      "tier": "Unclassified"
    },
    {
      "sku": "EX-35-H2-ARC",
      "description": "4K60Hz 4:4:4 HDBaseT™ Extender Set | Dolby Vision & HDR | ARC | PoH | RS232 & 2-Way IR Passthrough (4K: 35m/115ft, 1080p: 70m/230ft)",
      "family": "EX",
      "tier": "Unclassified"
    },
    {
      "sku": "EX-40-G3",
      "description": "1080p60Hz UTP Extender Set | IR Passthrough | PoC (1080p: 40m/131ft)",
      "family": "EX",
      "tier": "Unclassified"
    },
    {
      "sku": "EX-40-H2-ARC",
      "description": "4K60Hz 4:4:4 HDBaseT™ Extender Set | Dolby Vision & HDR | ARC | PoH | RS232 & 2-Way IR Passthrough (4K: 40m/115ft, 1080p: 70m/230ft)",
      "family": "EX",
      "tier": "Unclassified"
    },
    {
      "sku": "EX-40-KVM-5K",
      "description": "5K30Hz HDBT3.0 Extender Kit | Uncompressed video | HDMI Loop out | Audio de-embedding | Analog Audio pass-through | USB 2.0 | PoH | DIP Switch, RS232 control",
      "family": "EX",
      "tier": "Unclassified"
    },
    {
      "sku": "EX-60-USB2",
      "description": "USB2.0 Extender Set | 60m | 480Mbps | PoC (Tx - Rx) | 1x USB Host & 4x USB-A ports",
      "family": "EX",
      "tier": "Unclassified"
    },
    {
      "sku": "EX-70-G2",
      "description": "4K60Hz 4:2:0  HDBaseT™ Extender Set | PoC | RS232 & 2-Way IR Passthrough (4K: 35m/115ft, 1080p: 70m/230ft)",
      "family": "EX",
      "tier": "Unclassified"
    },
    {
      "sku": "EX-70-H2",
      "description": "4K60Hz 4:4:4 HDBaseT™ Extender Set | Dolby Vision & HDR | PoH | RS232 & 2-Way IR Passthrough (4K: 70m/230ft, 1080p: 100m/328ft)",
      "family": "EX",
      "tier": "Unclassified"
    },
    {
      "sku": "EX-80-KVM",
      "description": "1080p60Hz UTP Extender | USB 2.0 | PoC",
      "family": "EX",
      "tier": "Unclassified"
    },
    {
      "sku": "EX3-100-EARC",
      "description": "4K60Hz 4:4:4，5K30Hz 4:4:4 HDBaseT™ Extender Set | Test Pattern | Dolby Vision and HDR | eARC | Audio De-embedding | POH | Low-bandwidth mode | RS232 | 2 Way IR Passthrough 4K 60hz 100m (Cat6a)",
      "family": "EX3",
      "tier": "Unclassified"
    },
    {
      "sku": "EXA-100-EARC",
      "description": "HDMI 2.0 Audio Only Extender  | eARC | ARC | RS232 Passthrough l IR Passthrough | CEC Passthrough  | 100m/327ft",
      "family": "EXA",
      "tier": "Unclassified"
    },
    {
      "sku": "EXF-300-H2",
      "description": "4K60Hz 4:4:4 Multi-Mode Fiber Extender Set | Dolby Vision & HDR | IR or RS-232 Passthrough (4K: 300m/984ft)",
      "family": "EXF",
      "tier": "Unclassified"
    },
    {
      "sku": "EXP-4KUHD-0.5",
      "description": "0.5m/1.6ft HDMI 2.0\r\nCable | 18Gbps 4K60Hz\r\n| Dolby Vision & HDR\r\n|ARC,CEC, ALLM, VRR, |\r\nCL3 & VW-1 Rated",
      "family": "EXP",
      "tier": "Unclassified"
    },
    {
      "sku": "EXP-4KUHD-1.0",
      "description": "1m/3ft HDMI 2.0 Cable | 18Gbps  4K60Hz | Dolby Vision & HDR |ARC,CEC, ALLM, VRR, | CL3 &  VW-1 Rated",
      "family": "EXP",
      "tier": "Unclassified"
    },
    {
      "sku": "EXP-4KUHD-2.0",
      "description": "2m/6.5ft HDMI 2.0 Cable | 18Gbps  4K60Hz | Dolby Vision & HDR |ARC,CEC, ALLM, VRR, | CL3 &  VW-1 Rated",
      "family": "EXP",
      "tier": "Unclassified"
    },
    {
      "sku": "EXP-4KUHD-3.0",
      "description": "3m/10ft HDMI 2.0 Cable\r\n| 18Gbps 4K60Hz |\r\nDolby Vision & HDR\r\n|ARC,CEC, ALLM, VRR, |\r\nCL3 & VW-1 Rated",
      "family": "EXP",
      "tier": "Unclassified"
    },
    {
      "sku": "EXP-4KUHD-5.0",
      "description": "5m/15ft HDMI 2.0 Cable\r\n| 18Gbps 4K60Hz |\r\nDolby Vision & HDR\r\n|ARC,CEC, ALLM, VRR, |\r\nCL3 & VW-1 Rated",
      "family": "EXP",
      "tier": "Unclassified"
    },
    {
      "sku": "EXP-8KUHD-0.5",
      "description": "0.5m/1.6ft  HDMI 2.1 Cable | 48Gbps  8K60 | Dolby Vision & HDR | eARC, CEC, ALLM, VRR, QMS, QFT | CL3 & VW-1 Rated | UHS Certified",
      "family": "EXP",
      "tier": "Unclassified"
    },
    {
      "sku": "EXP-CAB-USBC-1M",
      "description": "1m/3.2ft USB-C to C Cable | SuperSpeed USB 20Gbps | 4K60 Alt-Mode | 100w PD",
      "family": "EXP",
      "tier": "Unclassified"
    },
    {
      "sku": "EXP-CAB-USBC-2M",
      "description": "2m/6.5ft USB-C to C Cable | SuperSpeed USB 20Gbps | 4K60 Alt-Mode | 100w PD",
      "family": "EXP",
      "tier": "Unclassified"
    },
    {
      "sku": "EXP-CAB-USBC-5M",
      "description": "5m/16.40ft USB-C to C cable | MicroCoax | 4K60 | 10Gbps (5Gbps/Lane) | 60W | USB 3.2 Gen 1x2",
      "family": "EXP",
      "tier": "Unclassified"
    },
    {
      "sku": "EXP-CON-AUD-H2",
      "description": "4K60Hz 4:4:4 HDMI 2.0 Audio Exractor with Passthrough | HDMI to S/PDIF or RCA | 4K60 | Dolby Vision & HDR",
      "family": "EXP",
      "tier": "Unclassified"
    },
    {
      "sku": "EXP-MX-0402-H2",
      "description": "4K60Hz 4:4:4 4x2 HDMI Matrix Switch | Dolby Vision & HDR | ARC | CEC | Audio De-embed",
      "family": "EXP",
      "tier": "Unclassified"
    },
    {
      "sku": "EXP-SP-0102-8K",
      "description": "8K60Hz  4:4:4 1x2 HDMI Splitter | Dolby Vision & HDR | Audio De-embed | Down-Scaler",
      "family": "EXP",
      "tier": "Unclassified"
    },
    {
      "sku": "EXP-SP-0102-H2",
      "description": "4K60Hz 4:4:4 1x2 HDMI Splitter | Dolby Vision & HDR | 4k > 1080p Down-Scaler",
      "family": "EXP",
      "tier": "Unclassified"
    },
    {
      "sku": "EXP-SP-0104-H2",
      "description": "4K60Hz 4:4:4  1x4 HDMI Splitter | Dolby Vision & HDR | 4k > 1080p Down-Scaler",
      "family": "EXP",
      "tier": "Unclassified"
    },
    {
      "sku": "EXP-SW-0201-8K",
      "description": "8K60Hz 4:4:4 2x1 HDMI Switcher | Dolby Vision & HDR | ARC | Audio De-embed | EDID Management",
      "family": "EXP",
      "tier": "Unclassified"
    },
    {
      "sku": "EXP-SW-0401-8K",
      "description": "8K60Hz 4:4:4 4x1 HDMI Switcher | Dolby Vision & HDR | ARC | Audio De-embed | EDID Management | RS232 Control",
      "family": "EXP",
      "tier": "Unclassified"
    },
    {
      "sku": "EXP-SW-0401-H2",
      "description": "4K60Hz 4:4:4 4x1 HDMI Switcher | Dolby Vision & HDR",
      "family": "EXP",
      "tier": "Unclassified"
    },
    {
      "sku": "FOCUS 200 Pro",
      "description": "4K AI Webcam | 120° DFOV | Gesture Control, Auto Framing and Presenter Tracking| Zoom certified |  USB 3.0 Support | Integrated Mic | High fram rate，ZOOM Certification",
      "family": "FOCUS 200 Pro",
      "tier": "Unclassified"
    },
    {
      "sku": "HALO-COM-MIC",
      "description": "Apollo™ companion mic | USB mini connection | Mounting on table",
      "family": "HALO",
      "tier": "Unclassified"
    },
    {
      "sku": "HALO-VX10-V2",
      "description": "HALO Video Bar mini  |  4K AI camera | 120° DFOV | Auto Framing and Presenter Tracking|Dual 5w stereo Speakers | ZOOM Certification",
      "family": "HALO",
      "tier": "Unclassified"
    },
    {
      "sku": "HALO 60",
      "description": "Compact USB Speakerphone | Omni-direction 4xMics | AEC &ANR &AGC | USB & Bluetooth | 2500mAh Battery",
      "family": "HALO 60",
      "tier": "Unclassified"
    },
    {
      "sku": "HALO 80",
      "description": "USB/Bluetooth Speakerphone | Daisy-chain up to 9 units | Omni-Direction 4xMics | AEC | Noise Reduction | 3W speaker | USB2.0",
      "family": "HALO 80",
      "tier": "Unclassified"
    },
    {
      "sku": "IDB-200-MS",
      "description": "Compact In-Desk Connectivity | HDMI & USB-C Passthrough | USB Charging | Multi-Standard Mains Outlet",
      "family": "IDB",
      "tier": "Unclassified"
    },
    {
      "sku": "IDB-300",
      "description": "Dual Channel CableBox | USB-C, HDMI+USB | Retractable | Cable management bag",
      "family": "IDB",
      "tier": "Unclassified"
    },
    {
      "sku": "IDB-300-BTN",
      "description": "Dual Channel CableBox | USB-C, HDMI+USB | Touch buttons with LEDs | Retractable | Cable management bag",
      "family": "IDB",
      "tier": "Unclassified"
    },
    {
      "sku": "IDB-400-MS",
      "description": "Flip Up In-Desk Connectivity | 2 HDMI & USB-C Passthrough | USB Charging | RJ-45 | Multi-Standard Mains Outlet",
      "family": "IDB",
      "tier": "Unclassified"
    },
    {
      "sku": "IDB-400-MS-C",
      "description": "Flip Up In-Desk Connectivity | USB Charging| Multi-Standard Mains Outlet | customized ports",
      "family": "IDB",
      "tier": "Unclassified"
    },
    {
      "sku": "IDB-CBL-SPINE",
      "description": "Under Desk Cable Management 'SPINE' for IDB Series (Adjustable up to 36\")",
      "family": "IDB",
      "tier": "Unclassified"
    },
    {
      "sku": "IDB-HDMI-C",
      "description": "HDMI | Passthrough coupling socket | Front HDMI female | Back HDMI female",
      "family": "IDB",
      "tier": "Unclassified"
    },
    {
      "sku": "IDB-K2-C",
      "description": "Carrier Keystone 2 ports | 45mm X 45mm | Black color",
      "family": "IDB",
      "tier": "Unclassified"
    },
    {
      "sku": "IDB-PWR-SCH",
      "description": "2m Wieland to Schuko Power Supply Cable For IDB-MS Series (Schuko Plug)",
      "family": "IDB",
      "tier": "Unclassified"
    },
    {
      "sku": "IDB-PWR-UK",
      "description": "2m Wieland to UK Power Supply Cable For IDB-MS Series (UK Plug)",
      "family": "IDB",
      "tier": "Unclassified"
    },
    {
      "sku": "IDB-RJ45-C",
      "description": "RJ45 CAT6 | Passthrough coupling socket | Front RJ45 female | Back RJ45 female | Unshielded",
      "family": "IDB",
      "tier": "Unclassified"
    },
    {
      "sku": "IDB-USBA-C",
      "description": "USB 3.0 type A | Passthrough coupling socket | Front USB A female | Back USB A female",
      "family": "IDB",
      "tier": "Unclassified"
    },
    {
      "sku": "IDB-USBC-C",
      "description": "USB 3.2 type C | Passthrough coupling socket | Front USB C female | Back USB C female",
      "family": "IDB",
      "tier": "Unclassified"
    },
    {
      "sku": "MX-0402-MST",
      "description": "Synergy 4K60Hz HDR 4x2 HDMI & USB-C Matrix Switcher with MST | Dual 60-Watt Charging | USB 3.2 | USB Passthrough 1Gbe | GPIO | Down-Scaling",
      "family": "MX",
      "tier": "Unclassified"
    },
    {
      "sku": "MX-0403-H3-MST",
      "description": "Synergy 4K60Hz HDR 4x3 HDMI & USB-C Matrix Switcher with MST & HDBaseT 3.0 Output| Dual 60-Watt Charging | USB 3.2 | USB Passthrough 1Gbe | GPIO | Down-Scaling",
      "family": "MX",
      "tier": "Unclassified"
    },
    {
      "sku": "MX-0404-HDMI",
      "description": "4K60Hz 4:4:4 4x4 HDMI Matrix | Dolby Vision & HDR | 4K-1080P Simple Scaler | Audio De-embed | CEC",
      "family": "MX",
      "tier": "Unclassified"
    },
    {
      "sku": "MX-0404-KIT",
      "description": "4K60Hz  4:2:0 4x4 (3 HDBaseT™, 1 HDMI) Matrix | PoH | Includes 3 Receivers | Audio De-embed (4K: 35m/114ft, 1080p: 70m/228ft)",
      "family": "MX",
      "tier": "Unclassified"
    },
    {
      "sku": "MX-0404-SCL",
      "description": "4K60Hz 4:4:4 4x4 HDMI Matrix | HDR | Seamless Switching | Multiview | Videowall | Scaling Outputs |Balanced Analog and S/PDIF Audio De-embed | CEC",
      "family": "MX",
      "tier": "Unclassified"
    },
    {
      "sku": "MX-0804-EDC",
      "description": "4K60Hz 4:4:4 8x4 Seamless Matrix | 7 HDMI & 1 USB-C input | 4 HDMI outputs | Audio DSP & Mixing | DANTE | Dolby Vision & HDR | CEC",
      "family": "MX",
      "tier": "Unclassified"
    },
    {
      "sku": "MX-0808-H2A-MK2",
      "description": "4K60Hz 4:4:4 8x8 HDMI Matrix | Dolby Vision & HDR | Scaling Outputs | Balanced Audio De-embed | ARC | CEC | Sygma",
      "family": "MX",
      "tier": "Unclassified"
    },
    {
      "sku": "MX-0808-KIT-V2",
      "description": "4K60Hz  4:2:0  8x8 HDBaseT™ Matrix | PoH | Includes 8 Receivers | 4x Mirrored HDMI | Audio De-embed (4K: 35m/114ft, 1080p: 70m/228ft)",
      "family": "MX",
      "tier": "Unclassified"
    },
    {
      "sku": "MX-0808-SCL",
      "description": "4K60 4:4:4 8x8 Seamless Scaling HDMI Matrix with USB-C | Audio De-embed | HDCP 2.3",
      "family": "MX",
      "tier": "Unclassified"
    },
    {
      "sku": "MX-0812-SCL",
      "description": "4K60 4:4:4 8x12 Advanced Seamless Scaling HDMI Matrix | Advanced Video Wall | Audio De-embed | HDCP 2.3",
      "family": "MX",
      "tier": "Unclassified"
    },
    {
      "sku": "MX-1007-HYB",
      "description": "4K60Hz 4:4:4 10x7 Seamless Matrix | 7 HDMI & 1 USB-C input | NetworkHD (500 series) & HDBT\r\nTM Inputs & outputs | Audio DSP, AMP & Mixing | DANTE | Dolby Vision & HDR | Routable CEC & RS232",
      "family": "MX",
      "tier": "Unclassified"
    },
    {
      "sku": "MX-1616-SCL",
      "description": "16 Slot - 4K60Hz 4:4:4 Seamless Empty Custom Matrix Chassis",
      "family": "MX",
      "tier": "Unclassified"
    },
    {
      "sku": "MXV-0404-H2A-KIT",
      "description": "4K60Hz  4:4:4 4x4 HDBaseT™ Matrix | Dolby Vision & HDR | PoH | Includes 4 Receivers | Audio De-embed | (4K: 35m/115ft, 1080p: 70m/230ft)",
      "family": "MXV",
      "tier": "Unclassified"
    },
    {
      "sku": "MXV-0808-H2A-70-V3",
      "description": "4K60Hz  4:4:4 8x8 HDBaseT™ Matrix | Dolby Vision & HDR | PoH |Audio De-embed | Routable CEC & RS232 (4K: 70m/230ft, 1080p: 100m/328ft)",
      "family": "MXV",
      "tier": "Unclassified"
    },
    {
      "sku": "MXV-0808-H2A-KIT",
      "description": "4K60Hz  4:4:4 8x8 HDBaseT™ Matrix  Kit w/ 6 standard receivers & 2 Scaling receivers | Dolby Vision & HDR | PoH |Audio De-embed | Routable CEC & RS232 (4K: 35m/115ft, 1080p: 70m/230ft)",
      "family": "MXV",
      "tier": "Unclassified"
    },
    {
      "sku": "MXV-0808-H2A-V3",
      "description": "4K60Hz  4:4:4 8x8 HDBaseT™ Matrix | Dolby Vision & HDR | PoH |Audio De-embed | Routable CEC & RS232 (4K: 35m/115ft, 1080p: 70m/230ft)",
      "family": "MXV",
      "tier": "Unclassified"
    },
    {
      "sku": "NetworkHD Touch™",
      "description": "Free iPad & Android Control App for NetworkHD 100, 200 & 400 Series",
      "family": "NetworkHD Touch™",
      "tier": "Unclassified"
    },
    {
      "sku": "NHD-000-RACK4",
      "description": "6U/12 Slot Rack Mount for all NetworkHD Series",
      "family": "NHD",
      "tier": "Unclassified"
    },
    {
      "sku": "NHD-0401-MV",
      "description": "NetworkHD 4-Input 4K60 Multiview Switcher | Dolby Vision & HDR | Audio De-embed | Compatible with 400 & 500 Series",
      "family": "NHD",
      "tier": "Unclassified"
    },
    {
      "sku": "NHD-124-TX",
      "description": "4K30Hz Quad Encoder",
      "family": "NHD",
      "tier": "Unclassified"
    },
    {
      "sku": "NHD-140-RACK-1U",
      "description": "1U/2 Slot Rack Mount for NHD-140-TX &NHD-124-TX Quad Encoder",
      "family": "NHD",
      "tier": "Unclassified"
    },
    {
      "sku": "NHD-150-RX",
      "description": "4K30Hz Decoder | 4K60HZ Output | PoE | 9-Window Multiview Processing | Tile & Overlap Layout | Audio De-embed | RS232 | CEC",
      "family": "NHD",
      "tier": "Unclassified"
    },
    {
      "sku": "NHD-510-TX",
      "description": "4K60Hz 4:4:4 Encoder | 1GbE | HDMI&USB-C Input | HDMI Loop out | Dolby Vision & HDR | PoE+ | USB 2.0 | Audio De-embed | SFP | IR & RS232 Routing | Dante AV-A",
      "family": "NHD",
      "tier": "Unclassified"
    },
    {
      "sku": "NHD-610-RX",
      "description": "4K60Hz 4:4:4 SDVoE Decoder | 10G RJ45| Dolby Vision & HDR | Video Wall | Multiview | PoE+ | Ethernet Passthrough | Audio De-embed | USB 2.0 | IR&RS232",
      "family": "NHD",
      "tier": "Unclassified"
    },
    {
      "sku": "NHD-610-TX",
      "description": "4K60Hz 4:4:4 SDVoE Encoder | 10G RJ45 | Dolby Vision & HDR | PoE+ | Ethernet Passthrough | Audio De-embed | Dante/AES67 | USB 2.0 | IR&RS232",
      "family": "NHD",
      "tier": "Unclassified"
    },
    {
      "sku": "NHD-610-TX-V2",
      "description": "4K60Hz 4:4:4 SDVoE Encoder | 10G RJ45 | Dolby Vision & HDR | PoE+ | Ethernet Passthrough | Audio De-embed | Dante/AES67 | USB HID | IR&RS232",
      "family": "NHD",
      "tier": "Unclassified"
    },
    {
      "sku": "NHD-CTL-PRO-V2",
      "description": "Pro Controller for NetworkHD Series | PoE | Dual NIC Network Isolation | Advanced Setup Interface & Wizard",
      "family": "NHD",
      "tier": "Unclassified"
    },
    {
      "sku": "NHD-RACK-1U",
      "description": "1U/2 Slot Rack Mount for NetworkHD™ 110/120/500/600/CTL",
      "family": "NHD",
      "tier": "Unclassified"
    },
    {
      "sku": "NHD-RACK4-BLK",
      "description": "Blanking Plate for NHD-000-RACK4",
      "family": "NHD",
      "tier": "Unclassified"
    },
    {
      "sku": "NHD-USB-TRX",
      "description": "USB 2.0 over IP Transceiver | 1GbE | USB-A & USB-B Ports | SFP | PoE+ | USB Hub",
      "family": "NHD",
      "tier": "Unclassified"
    },
    {
      "sku": "NHD-120-IW-TX",
      "description": "4K30Hz 2-Gang In-Wall Encoder | PoE | Audio De-embed | IR TX | 1GbE Port for 3rd Device Passthrough",
      "family": "NHD-120",
      "tier": "Bronze"
    },
    {
      "sku": "NHD-120-RX",
      "description": "4K30Hz Decoder | PoE | Audio De-embed | Video Wall | IR & RS232 Routing | CEC",
      "family": "NHD-120",
      "tier": "Bronze"
    },
    {
      "sku": "NHD-120-TX",
      "description": "4K30Hz Encoder | PoE | Audio De-embed | IR & RS232 Routing",
      "family": "NHD-120",
      "tier": "Bronze"
    },
    {
      "sku": "NHD-500-DNT-TX",
      "description": "4K60Hz 4:4:4 Encoder | 2GbE RJ45 + SFP | Dolby Vision & HDR | PoE | USB 2.0 | Audio De-embed | Fiber | IR & RS232 Routing / Dante AES67",
      "family": "NHD-500",
      "tier": "Silver"
    },
    {
      "sku": "NHD-500-E-RX",
      "description": "Lite 4K60Hz 4:4:4 Decoder | 1GbE | Dolby Vision & HDR | PoE | RS232",
      "family": "NHD-500",
      "tier": "Silver"
    },
    {
      "sku": "NHD-500-E-TX",
      "description": "Lite 4K60Hz 4:4:4 Encoder | 1GbE | Dolby Vision & HDR | PoE | Audio De-embed | IR",
      "family": "NHD-500",
      "tier": "Silver"
    },
    {
      "sku": "NHD-500-IW-TX",
      "description": "4K60Hz 4:4:4 2-Gang In-Wall Encoder | HDMI & USB-C Inputs | PoE | 1GbE | Dolby Vision & HDR | USB 2.0",
      "family": "NHD-500",
      "tier": "Silver"
    },
    {
      "sku": "NHD-500-RX",
      "description": "4K60Hz 4:4:4 Decoder | 1GbE | Dolby Vision & HDR | PoE | USB 2.0 | Video Wall | Audio De-embed | ARC | S/PDIF | SFP | CEC | IR & RS232 Routing",
      "family": "NHD-500",
      "tier": "Silver"
    },
    {
      "sku": "NHD-500-TX",
      "description": "4K60Hz 4:4:4 Encoder | 1GbE | Dolby Vision & HDR | PoE | USB 2.0 | Audio De-embed | ARC | S/PDIF | SFP | IR & RS232 Routing",
      "family": "NHD-500",
      "tier": "Silver"
    },
    {
      "sku": "NHD-600-TRX",
      "description": "4K60Hz 4:4:4 SDVoE Transceiver | 10G RJ45 | Dolby Vision & HDR | Video Wall | Multiview | PoE+ | Ethernet Passthrough | Audio De-embed | USB HID | IR & RS232",
      "family": "NHD-600",
      "tier": "Gold"
    },
    {
      "sku": "NHD-600-TRXF",
      "description": "4K60Hz 4:4:4 SDVoE Fiber Transceiver | 10G SFP+ | Dolby Vision & HDR | Video Wall | Multiview | Ethernet Passthrough | Audio De-embed | USB 2.0 | IR&RS232",
      "family": "NHD-600",
      "tier": "Gold"
    },
    {
      "sku": "RX-35-POH",
      "description": "4K60Hz 4:2:0  HDBaseT™ Receiver | PoH | IR & RS232 Passthrough (4K: 35m/115ft, 1080p: 70m/230ft) [For TX-35-IW]",
      "family": "RX",
      "tier": "Unclassified"
    },
    {
      "sku": "RX-500",
      "description": "4K60Hz (4:2:0 8bit) HDBaseT 2.0 Receiver | PoH | USB 2.0 | Audio De-embed | RS232 Passthrough (4K: 35m/115ft, 1080p: 70m/230ft) [For APO/SW Products]",
      "family": "RX",
      "tier": "Unclassified"
    },
    {
      "sku": "RX-500",
      "description": "4K60Hz 4:2:0  HDBaseT 2.0 Receiver | PoH | USB 2.0 | Audio De-embed | RS232 Passthrough (4K: 35m/115ft, 1080p: 70m/230ft) [For APO/SW Products]",
      "family": "RX",
      "tier": "Unclassified"
    },
    {
      "sku": "RX-70-4K",
      "description": "4K60Hz 4:2:0  HDBaseT™ Receiver | PoH | Ethernet, IR & RS232 Passthrough (4K: 70m/230ft, 1080p: 100m/328ft) [For TX-70-4K]",
      "family": "RX",
      "tier": "Unclassified"
    },
    {
      "sku": "RX-70-4K-SCL",
      "description": "4K60Hz 4:2:0  HDBaseT™ Scaling Receiver | PoH | Ethernet, IR & RS232 Passthrough |ARC (4K: 70m/230ft, 1080p: 100m/328ft)",
      "family": "RX",
      "tier": "Unclassified"
    },
    {
      "sku": "RX-700",
      "description": "4K60Hz 4:2:0  HDBaseT Receiver  | PoH | USB 2.0 | DSC | Audio De-embed | RS232 & IR Passthrough (4K: 100m/328ft) [For SW-130-TX]",
      "family": "RX",
      "tier": "Unclassified"
    },
    {
      "sku": "RX3-100",
      "description": "4K60Hz 4:4:4,5K30Hz 4:4:4 HDBaseT 3.0 Receiver | PoH | USB2.0 | CEC | RS232 passthrough | audio De-embed (4K: 100m/328ft) [For SW-120-TX3 & MX-1007-HYB]",
      "family": "RX3",
      "tier": "Unclassified"
    },
    {
      "sku": "RX3-100",
      "description": "4K60Hz 4:4:4 HDBaseT 3.0 Receiver | PoH | USB2.0 | CEC | RS232 passthrough | audio De-embed (4K: 100m/328ft) [For SW-120-TX3 & MX-1007-HYB]",
      "family": "RX3",
      "tier": "Unclassified"
    },
    {
      "sku": "RXF-300-4K",
      "description": "4K60Hz 4:4:4  Fiber Receiver | IR & RS232 Passthrough (4K:300m/984ft) [For H2XC]",
      "family": "RXF",
      "tier": "Unclassified"
    },
    {
      "sku": "RXV-35-4K",
      "description": "4K60Hz 4:4:4 HDBaseT Receiver | PoH | IR & RS232 Passthrough (4K: 35m/115ft, 1080p: 70m/230ft) [For MXV]",
      "family": "RXV",
      "tier": "Unclassified"
    },
    {
      "sku": "RXV-35-SCL",
      "description": "4K60Hz 4:4:4 HDBaseT Scaling Receiver | PoH | Audio De-embed | IR & RS232 Passthrough (4K: 35m/115ft, 1080p: 70m/230ft) [For MXV]",
      "family": "RXV",
      "tier": "Unclassified"
    },
    {
      "sku": "RXV-70-4K-G2",
      "description": "4K60Hz 4:4:4 HDBaseT Receiver | PoH | IR & RS232 Passthrough (4K: 70m/230ft, 1080p: 100m/328ft) [For MXV-70]",
      "family": "RXV",
      "tier": "Unclassified"
    },
    {
      "sku": "RXV-70-G2-SCL",
      "description": "4K60Hz 4:4:4  HDBaseT Scaling Receiver | PoH | Audio De-embed | IR & RS232 Passthrough (4K: 70m/230ft, 1080p: 100m/328ft) [For MXV-70]",
      "family": "RXV",
      "tier": "Unclassified"
    },
    {
      "sku": "SP-0104-H2",
      "description": "4K60Hz 4:4:4 1x4 HDMI Splitter | Dolby Vision & HDR | EDID Management",
      "family": "SP",
      "tier": "Unclassified"
    },
    {
      "sku": "SP-0108-SCL",
      "description": "4K60Hz 4:4:4 1x8 HDMI Splitter | Dolby Vision & HDR | EDID Management | Down-Scaling | Audio De-embed",
      "family": "SP",
      "tier": "Unclassified"
    },
    {
      "sku": "SW-0204-VW",
      "description": "4K 60Hz 4-Output Video Wall |  1x4, 2x2 layout |Ultra-wide resolution support  | WEB GUI and RS232 control",
      "family": "SW",
      "tier": "Unclassified"
    },
    {
      "sku": "SW-0206-VW",
      "description": "4K 60Hz 6-Output Video Wall |  Cascading up to 6 devices | Multi-fast layout and customized layout |Ultra-wide resolution support  | WEB GUI and RS232 control",
      "family": "SW",
      "tier": "Unclassified"
    },
    {
      "sku": "SW-120-TX3",
      "description": "4K60Hz 4:4:4, 5K30Hz 4:4:4(HDMI) HDBaseT 3.0 Transmitter | HDMI & USB-C input | PoH | USB2.0 | RS232 passthrough (4K: 100m/328ft) [For RX3-100 & MX-1007-HYB]",
      "family": "SW",
      "tier": "Unclassified"
    },
    {
      "sku": "SW-120-TX3-UK",
      "description": "4K60Hz 4:4:4, 5K30Hz 4:4:4(HDMI) HDBaseT 3.0 2-Gang In-Wall Transmitter | HDMI & USB-C input | PoH | USB2.0 | RS232 passthrough (4K: 100m/328ft) [For RX3-100 & MX-1007-HYB]",
      "family": "SW",
      "tier": "Unclassified"
    },
    {
      "sku": "SW-120-TX3-UK",
      "description": "4K60Hz 4:4:4 HDBaseT 3.0 2-Gang In-Wall Transmitter | HDMI & USB-C input | PoH | USB2.0 | RS232 passthrough (4K: 100m/328ft) [For RX3-100 & MX-1007-HYB]",
      "family": "SW",
      "tier": "Unclassified"
    },
    {
      "sku": "SW-130-TX-UK",
      "description": "3-Input 4K60Hz 4:2:0 In-wall HDBaseT™ Switcher | 2 HDMI + USB-C | CEC  | 2-Gang (4K: 100m/328ft)",
      "family": "SW",
      "tier": "Unclassified"
    },
    {
      "sku": "SW-220-TX-W",
      "description": "Synergy™ 2-Input 4K30Hz Switcher | USB 3.0 | Airplay & Miracast | Dual-View | Supports APO-DG1 Dongle",
      "family": "SW",
      "tier": "Unclassified"
    },
    {
      "sku": "SW-510-TX",
      "description": "Synergy™ 4-input 4K60Hz 4:2:0 HDBaseT™  Switcher | USB 2.0 | Ethernet Passthrough | IR, CEC & RS232 Passthrough (4K: 100m/328ft)",
      "family": "SW",
      "tier": "Unclassified"
    },
    {
      "sku": "SW-515-RX",
      "description": "Synergy™ 3-input 4K60Hz 4:2:0 HDBaseT™ Switching Receiver | USB 2.0 | Ethernet Passthrough | Relays | IR, CEC & RS232 Passthrough (4K: 100m/328ft)",
      "family": "SW",
      "tier": "Unclassified"
    },
    {
      "sku": "SW-640L-TX-W",
      "description": "Synergy 4-Input 4K60Hz Presentation Switcher | USB-C 60W PD | USB-C Ethernet | 2 HDMI Matrix Outputs | USB 3.0 | Quad View | Airplay & Miracast | Wireless Presentation & Conference with APO-DG2 & APO-DG2-PRO",
      "family": "SW",
      "tier": "Unclassified"
    },
    {
      "sku": "SYN-CTL-HUB",
      "description": "Ethernet Protocol Converter for the SYN-TOUCH10 | RS232 | Relay | IR",
      "family": "SYN",
      "tier": "Unclassified"
    },
    {
      "sku": "SYN-KEY10",
      "description": "Synergy™ 10-button Keypad Controller | Only comes with US back box",
      "family": "SYN",
      "tier": "Unclassified"
    },
    {
      "sku": "SYN-TOUCH10",
      "description": "Synergy™ 10.1” All-In-One Touchpad IP Controller | PoE+ | Table Top Stand & Wall-Mount (US/UK/EU Compatible)",
      "family": "SYN",
      "tier": "Unclassified"
    },
    {
      "sku": "TS-280-EU",
      "description": "2-Gang 2.8\" Touchscreen Controller for Presentation Switcher Solutions",
      "family": "TS",
      "tier": "Unclassified"
    },
    {
      "sku": "TX-35-IW",
      "description": "4K60Hz 4:2:0   HDBaseT™ Single Gang In-Wall Transmitter | PoH | IR & RS232 Passthrough (4K: 35m/115ft, 1080p: 70m/230ft)",
      "family": "TX",
      "tier": "Unclassified"
    },
    {
      "sku": "TX-35-IW-KVM",
      "description": "4K60Hz 4:2:0   HDMI & USB Single Gange In-Wall HDBT 2.0 Transmitter | HDMI 1.4 | HDCP 2.2 | 35m 4K 60 4:2:0",
      "family": "TX",
      "tier": "Unclassified"
    },
    {
      "sku": "TX-35-IWC-KVM",
      "description": "4K60Hz 4:2:0  USB C Single Gang In-Wall HDBT 2.0 Transmitter | DP Alt Mode (4-Lane) | HDCP 2.2 | 35m 4K 60 4:2:0 | PoH | RS232 | USB 2.0",
      "family": "TX",
      "tier": "Unclassified"
    },
    {
      "sku": "TX-SCL-HDBT",
      "description": "4K60Hz 4:2:0 HDBaseT™ Scaling  Output Card for MX-1616-SCL | HDR | PoH | Audio De-Embed (4K: 100m/328ft)",
      "family": "TX",
      "tier": "Unclassified"
    },
    {
      "sku": "TX-SCL-HDMI",
      "description": "4K60Hz 4:4:4HDMI Scaling Output Card for MX-1616-SCL | HDR | Audio De-embed",
      "family": "TX",
      "tier": "Unclassified"
    },
    {
      "sku": "USB-HUB4",
      "description": "4-Port 5Gbps Superspeed USB 3.2 Hub",
      "family": "USB",
      "tier": "Unclassified"
    }
  ]
};
export default catalog;



