import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { WM_ROUTES } from "@/core/wingman/routeMap";
import { saveActiveProject } from "@/app/logic/wingmanProjectState";
import {
  buildDiscoveryPersistedProject,
  upsertPersistedProject,
} from "@/app/logic/wingmanProjectPersistence";
import { WingmanWorkflowShell } from "@/features/wingmanUx/WingmanWorkflowShell";

type OutcomePath =
  | "Extender / point-to-point"
  | "Splitter / one-to-many"
  | "Matrix / presentation switching"
  | "AV over IP distribution"
  | "Video wall design";

const outcomeOptions: { label: OutcomePath; summary: string; hints: string[] }[] = [
  {
    label: "Extender / point-to-point",
    summary: "Use when a single source needs to reach a single destination over distance.",
    hints: ["Distance-led", "Single route", "Simple transport"],
  },
  {
    label: "Splitter / one-to-many",
    summary: "Use when one source needs to be mirrored to multiple displays.",
    hints: ["Mirrored outputs", "Simple distribution", "Fixed source"],
  },
  {
    label: "Matrix / presentation switching",
    summary: "Use when multiple sources must be switched between one or more displays.",
    hints: ["Multiple sources", "Routing control", "Room switching"],
  },
  {
    label: "AV over IP distribution",
    summary: "Use when the site needs flexible routing over managed network infrastructure.",
    hints: ["Network transport", "Scalable", "Multi-zone"],
  },
  {
    label: "Video wall design",
    summary: "Use when the display canvas and processing strategy are the primary design driver.",
    hints: ["Display canvas", "Processor strategy", "Wall planning"],
  },
];

export default function DiscoveryWizardPage() {
  const navigate = useNavigate();

  const [outcome, setOutcome] = useState<OutcomePath>("Matrix / presentation switching");
  const [displayCount, setDisplayCount] = useState("2");
  const [sourceCount, setSourceCount] = useState("3");
  const [distance, setDistance] = useState("15");
  const [usbNeeds, setUsbNeeds] = useState("No");
  const [networkReady, setNetworkReady] = useState("No");
  const [futureExpansion, setFutureExpansion] = useState("No");
  const [notes, setNotes] = useState("");

  const recommendation = useMemo(() => {
    const displays = Number(displayCount) || 0;
    const sources = Number(sourceCount) || 0;
    const dist = Number(distance) || 0;
    const networkIsReady = networkReady === "Yes";
    const expansionExpected = futureExpansion === "Yes";

    const avoipScore =
      (sources >= 3 ? 2 : 0) +
      (displays >= 3 ? 2 : 0) +
      (outcome === "Video wall design" ? 3 : 0) +
      (dist > 30 ? 1 : 0) +
      (networkIsReady ? 2 : 0) +
      (expansionExpected ? 2 : 0);

    let nextTool = "Catalogue";
    if (outcome === "Video wall design") nextTool = "Video Wall";
    if (outcome === "Matrix / presentation switching") nextTool = "Proposal";
    if (outcome === "AV over IP distribution") nextTool = "Catalogue";

    const architecture =
      outcome === "AV over IP distribution" || (avoipScore >= 5 && networkIsReady)
        ? "An AV over IP architecture is likely justified for this opportunity."
        : outcome === "Extender / point-to-point"
          ? "A direct transport path is the likely starting point."
          : outcome === "Splitter / one-to-many"
            ? "Simple mirrored distribution is the likely starting point."
            : outcome === "Matrix / presentation switching"
              ? "A switching-led architecture is the likely starting point."
              : "A display-canvas-led design flow is the likely starting point.";

    const transport =
      avoipScore >= 5 && networkIsReady
        ? "AVoIP should be considered because routing flexibility, scalability, and network readiness are present."
        : dist > 30
          ? "Distance suggests HDBaseT or AV over IP should be considered."
          : "Distance appears suitable for standard room-scale transport, depending on signal requirements.";

    const complexity =
      displays >= 4 || sources >= 4
        ? "This looks like a medium-to-higher complexity opportunity."
        : "This looks like a compact to medium opportunity.";

    return { nextTool, architecture, transport, complexity };
  }, [outcome, displayCount, sourceCount, distance, networkReady, futureExpansion]);

  const handleOpenNextTool = () => {
    const numericSources = Number(sourceCount || 0);
    const numericDisplays = Number(displayCount || 0);
    const numericDistance = Number(distance || 0);

    const isUsbRequired = usbNeeds === "Yes";
    const isNetworkReady = networkReady === "Yes";
    const isFutureExpansion = futureExpansion === "Yes";
    const isVideoWall = outcome === "Video wall design";
    const isWireless = outcome === "AV over IP distribution";

    const discoveryPayload = {
      name: "New Wingman Project",
      customer: "",
      application: outcome,
      roomType: outcome,
      notes,
      avGuide: {
        usb: isUsbRequired ? "USB / BYOD required" : "No USB requirement",
        audio: "",
        control:
          outcome === "Matrix / presentation switching"
            ? "Room switching control required"
            : outcome === "AV over IP distribution"
              ? "Network-routed control likely required"
              : "",
      },
      videoWall: {
        wallType: isVideoWall ? "Video Wall" : "",
      },
      discovery: {
        sources: numericSources,
        sourceCount: numericSources,
        displays: numericDisplays,
        displayCount: numericDisplays,
        distanceM: numericDistance,
        distance: numericDistance,
        resolution: "",
        notes,
        usbRequired: isUsbRequired,
        wireless: isWireless,
        videoWall: isVideoWall,
        advancedMultiview: isVideoWall && numericDisplays >= 4,
        hybridMeeting: isUsbRequired && outcome === "Matrix / presentation switching",
        networkReady: isNetworkReady,
        futureExpansion: isFutureExpansion,
      },
    };

    saveActiveProject({
      name: discoveryPayload.name,
      customer: discoveryPayload.customer,
      application: discoveryPayload.application,
      roomType: discoveryPayload.roomType,
      discovery: discoveryPayload.discovery,
      updatedAt: new Date().toISOString(),
    });

    const persisted = buildDiscoveryPersistedProject(discoveryPayload);
    upsertPersistedProject(persisted);

    navigate(
      recommendation.nextTool === "Video Wall"
        ? WM_ROUTES.videoWall
        : recommendation.nextTool === "Proposal"
          ? WM_ROUTES.proposal
          : WM_ROUTES.catalog,
    );
  };

  const rightRail = (
    <>
      <section className="wmx-right-panel">
        <div className="wmx-right-title">Design Direction</div>
        <div className="wmx-alert-list">
          <div className="wmx-alert-item">
            <div className="wmx-alert-dot wmx-alert-dot--info" />
            <div className="wmx-alert-copy">
              <strong>Architecture</strong>
              <span>{recommendation.architecture}</span>
            </div>
          </div>
          <div className="wmx-alert-item">
            <div className="wmx-alert-dot wmx-alert-dot--info" />
            <div className="wmx-alert-copy">
              <strong>Transport</strong>
              <span>{recommendation.transport}</span>
            </div>
          </div>
          <div className="wmx-alert-item">
            <div className="wmx-alert-dot wmx-alert-dot--good" />
            <div className="wmx-alert-copy">
              <strong>Complexity</strong>
              <span>{recommendation.complexity}</span>
            </div>
          </div>
        </div>
      </section>

      <section className="wmx-right-panel">
        <div className="wmx-right-title">Next Tool</div>
        <div className="wmx-summary-metric">
          <span>Recommended handoff</span>
          <strong>{recommendation.nextTool}</strong>
        </div>
      </section>
    </>
  );

  return (
    <WingmanWorkflowShell
      activeStage="discovery"
      projectName="New Wingman Project"
      sourceCount={Number(sourceCount || 0)}
      displayCount={Number(displayCount || 0)}
      distanceM={Number(distance || 0)}
      systemType={recommendation.nextTool}
      rightRail={rightRail}
    >
      <section className="wmx-section">
        <div className="wmx-section-header">
          <h1>System Intent</h1>
          <p>Select the primary design outcome</p>
        </div>

        <div className="wmx-card-row">
          {outcomeOptions.map((item) => {
            const active = item.label === outcome;
            return (
              <article
                key={item.label}
                className={`wmx-config-card${active ? " is-selected" : ""}`}
                onClick={() => setOutcome(item.label)}
                style={{ cursor: "pointer" }}
              >
                <div className="wmx-config-title">{item.label}</div>
                <div className="wmx-config-copy">{item.summary}</div>
                <div className="wmx-config-stats">
                  {item.hints.map((h) => (
                    <span key={h}>{h}</span>
                  ))}
                </div>
              </article>
            );
          })}
        </div>
      </section>

      <section className="wmx-section">
        <div className="wmx-section-header">
          <h2>System Signals</h2>
          <p>Define scale, distance, and constraints</p>
        </div>

        <div className="wmx-card-row">
          <div className="wmx-config-card">
            <div className="wmx-config-title">Displays</div>
            <input
              className="wm-input-dark"
              type="number"
              value={displayCount}
              onChange={(e) => setDisplayCount(e.target.value)}
            />
          </div>

          <div className="wmx-config-card">
            <div className="wmx-config-title">Sources</div>
            <input
              className="wm-input-dark"
              type="number"
              value={sourceCount}
              onChange={(e) => setSourceCount(e.target.value)}
            />
          </div>

          <div className="wmx-config-card">
            <div className="wmx-config-title">Distance (m)</div>
            <input
              className="wm-input-dark"
              type="number"
              value={distance}
              onChange={(e) => setDistance(e.target.value)}
            />
          </div>
        </div>

        <div className="wmx-card-row">
          <div className="wmx-config-card">
            <div className="wmx-config-title">USB</div>
            <select
              className="wm-select-dark"
              value={usbNeeds}
              onChange={(e) => setUsbNeeds(e.target.value)}
            >
              <option>Yes</option>
              <option>No</option>
            </select>
          </div>

          <div className="wmx-config-card">
            <div className="wmx-config-title">Network Ready</div>
            <select
              className="wm-select-dark"
              value={networkReady}
              onChange={(e) => setNetworkReady(e.target.value)}
            >
              <option>Yes</option>
              <option>No</option>
            </select>
          </div>

          <div className="wmx-config-card">
            <div className="wmx-config-title">Future Expansion</div>
            <select
              className="wm-select-dark"
              value={futureExpansion}
              onChange={(e) => setFutureExpansion(e.target.value)}
            >
              <option>Yes</option>
              <option>No</option>
            </select>
          </div>
        </div>

        <div className="wmx-data-panel">
          <div className="wmx-panel-title">Notes</div>
          <textarea
            className="wm-textarea-dark"
            placeholder="Capture room notes, application detail, or priorities."
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
          />
        </div>
      </section>

      <section className="wmx-section">
        <div className="wmx-panel-action">
          <button
            type="button"
            className="wmx-primary-btn"
            onClick={handleOpenNextTool}
          >
            Continue to {recommendation.nextTool}
          </button>
        </div>
      </section>
    </WingmanWorkflowShell>
  );
}