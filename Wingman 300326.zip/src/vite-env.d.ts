/// <reference types="vite/client" />

declare const __APP_VERSION__: string;
declare const __APP_BUILD_COMMIT__: string;
declare const __APP_BUILD_NUMBER__: string;
declare const __APP_BUILD_DATE__: string;
declare const __APP_BUILD_CHANNEL__: string;
